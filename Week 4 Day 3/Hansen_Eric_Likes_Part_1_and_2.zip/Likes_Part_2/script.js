let neilLikes = document.querySelector('#neil-likes');

function  increaseNeilLikes() {
    neilLikes.innerText++;
}

let nicholeLikes = document.querySelector('#nichole-lies');

function increaseNicholeLikes() {
    nicholeLikes.innerText++;
}

let jimLikes = document.querySelector('#jim-likes');

function increaseJimLikes() {
    jimLikes.innerText++;
}