let userLikes = document.querySelector('#user-likes');

function  increaseUserLikes() {
    userLikes.innerText++;
}