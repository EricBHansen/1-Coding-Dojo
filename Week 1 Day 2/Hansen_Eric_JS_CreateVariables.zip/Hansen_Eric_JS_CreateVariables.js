var height 
var age
/*There are two variables we are looking for: height and age. 
If height > 42 and age > 10, then the person can ride the ride.
If not, go to kiddie land. */
