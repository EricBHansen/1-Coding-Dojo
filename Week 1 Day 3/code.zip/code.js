//this will set the variable varCount to 0
var likeCount = 0;
//this will create a function that uses the variable varCount
function increaseLikes() {
    likeCount = likeCount +1;
}