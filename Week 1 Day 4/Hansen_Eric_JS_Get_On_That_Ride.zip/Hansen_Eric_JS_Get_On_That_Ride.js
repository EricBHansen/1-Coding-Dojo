var height 
var age
if (height => 42) {
    console.log("Get on that ride, kiddo!");
} else {
    console.log("Sorry, kiddo. Maybe next year.");
}

var age
var height

if (age =< 10) {
    console.log("Sorry, kiddo. Maybe next year.");
} else {
    if (height => 42) {
        console.log("Get on that ride, kiddo!");
    } else {
        console.log("Sorry, kiddo. Maybe next year.");
    }
}
