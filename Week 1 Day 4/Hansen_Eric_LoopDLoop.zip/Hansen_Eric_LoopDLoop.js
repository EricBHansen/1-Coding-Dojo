for (var distance = 1; distance <= 6; distance ++) {
    console.log("Have a candy");
}